package practice01;

public class Main {

    public static void main(String[] args) {
	// write your code here

//        System.out.println(Practice.isLeapYear(2400));
        // 0 1 1 2 3 5 8
        System.out.println(Practice.Fib(4));
    }
}
